import { Router } from "express";
const router = Router();

router.get("/", (_, res) => {
  res.json({ message: "Usuarios endpoint listo" });
});

export default router;