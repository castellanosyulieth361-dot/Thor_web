import { Router } from "express";
import { z } from "zod";
import { pool } from "../db.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";

const router = Router();

// 1) Crear formulario (por grupo)
const crearFormularioSchema = z.object({
  nombre: z.string().min(2),
  grupo_id: z.number().int().positive()
});

router.post("/", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { nombre, grupo_id } = crearFormularioSchema.parse(req.body);

    // Un grupo debe tener 1 formulario (regla recomendada)
    const existe = await pool.query(
      "SELECT id FROM formularios WHERE grupo_id = $1",
      [grupo_id]
    );
    if (existe.rowCount > 0) {
      return res.status(409).json({ message: "Ese grupo ya tiene un formulario creado" });
    }

    const r = await pool.query(
      "INSERT INTO formularios (nombre, grupo_id) VALUES ($1, $2) RETURNING *",
      [nombre.trim(), grupo_id]
    );

    res.status(201).json(r.rows[0]);
  } catch (err) {
    if (err?.name === "ZodError") return res.status(400).json({ message: "Datos inválidos", issues: err.issues });
    console.error(err);
    res.status(500).json({ message: "Error creando formulario" });
  }
});

// 2) Listar formularios
router.get("/", requireAuth, requireAdmin, async (_req, res) => {
  const r = await pool.query(
    `SELECT f.id, f.nombre, f.grupo_id, g.nombre AS grupo, f.creado_en
     FROM formularios f
     LEFT JOIN grupos_maquinaria g ON g.id = f.grupo_id
     ORDER BY f.creado_en DESC`
  );
  res.json(r.rows);
});

// 3) Obtener formulario con preguntas (para render Google Forms)
router.get("/:id", requireAuth, requireAdmin, async (req, res) => {
  const { id } = req.params;

  const formRes = await pool.query(
    `SELECT f.id, f.nombre, f.grupo_id, g.nombre AS grupo
     FROM formularios f
     LEFT JOIN grupos_maquinaria g ON g.id = f.grupo_id
     WHERE f.id = $1`,
    [id]
  );
  const form = formRes.rows[0];
  if (!form) return res.status(404).json({ message: "Formulario no existe" });

  const pregRes = await pool.query(
    `SELECT id, enunciado, orden, activa
     FROM formulario_preguntas
     WHERE formulario_id = $1
     ORDER BY orden ASC`,
    [id]
  );

  res.json({ formulario: form, preguntas: pregRes.rows });
});

// 4) Agregar pregunta (dinámico, tipo Google Forms)
const crearPreguntaSchema = z.object({
  enunciado: z.string().min(2),
  orden: z.number().int().positive().optional()
});

router.post("/:id/preguntas", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { enunciado, orden } = crearPreguntaSchema.parse(req.body);

    // Si no envían orden, la ponemos al final
    let finalOrden = orden;
    if (!finalOrden) {
      const maxRes = await pool.query(
        "SELECT COALESCE(MAX(orden), 0) AS max FROM formulario_preguntas WHERE formulario_id=$1",
        [id]
      );
      finalOrden = Number(maxRes.rows[0].max) + 1;
    }

    const r = await pool.query(
      `INSERT INTO formulario_preguntas (formulario_id, enunciado, orden)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [id, enunciado.trim(), finalOrden]
    );

    res.status(201).json(r.rows[0]);
  } catch (err) {
    if (err?.name === "ZodError") return res.status(400).json({ message: "Datos inválidos", issues: err.issues });
    console.error(err);
    res.status(500).json({ message: "Error creando pregunta" });
  }
});

// 5) Editar pregunta (texto u orden)
const editarPreguntaSchema = z.object({
  enunciado: z.string().min(2).optional(),
  orden: z.number().int().positive().optional()
});

router.put("/:formId/preguntas/:pregId", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { formId, pregId } = req.params;
    const { enunciado, orden } = editarPreguntaSchema.parse(req.body);

    const r = await pool.query(
      `UPDATE formulario_preguntas
       SET enunciado = COALESCE($1, enunciado),
           orden = COALESCE($2, orden)
       WHERE id=$3 AND formulario_id=$4
       RETURNING *`,
      [enunciado?.trim() ?? null, orden ?? null, pregId, formId]
    );

    if (r.rowCount === 0) return res.status(404).json({ message: "Pregunta no existe" });
    res.json(r.rows[0]);
  } catch (err) {
    if (err?.name === "ZodError") return res.status(400).json({ message: "Datos inválidos", issues: err.issues });
    console.error(err);
    res.status(500).json({ message: "Error editando pregunta" });
  }
});

// 6) Activar / desactivar pregunta
router.patch("/:formId/preguntas/:pregId/activa", requireAuth, requireAdmin, async (req, res) => {
  const { formId, pregId } = req.params;
  const { activa } = req.body;

  const r = await pool.query(
    `UPDATE formulario_preguntas
     SET activa = $1
     WHERE id=$2 AND formulario_id=$3
     RETURNING *`,
    [Boolean(activa), pregId, formId]
  );

  if (r.rowCount === 0) return res.status(404).json({ message: "Pregunta no existe" });
  res.json(r.rows[0]);
});

export default router;