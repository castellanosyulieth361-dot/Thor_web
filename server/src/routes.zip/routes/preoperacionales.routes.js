import { Router } from "express";
import { z } from "zod";
import { pool } from "../db.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

const schema = z.object({
  maquinaria_id: z.string().uuid(),
  observacion_general: z.string().optional(),
  ubicacion: z.enum(["bodega_98", "campo"]),
  ciudad: z.string().optional(),
  respuestas: z.array(
    z.object({
      pregunta_id: z.string().uuid(),
      cumple: z.boolean(),
      observacion: z.string().optional(),
      foto_url: z.string().optional()
    })
  ).min(1)
});

router.post("/", requireAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    const data = schema.parse(req.body);

    // Regla: si NO cumple, debe tener al menos observación o foto (puedes ajustar)
    for (const r of data.respuestas) {
      if (r.cumple === false) {
        const obs = (r.observacion ?? "").trim();
        const foto = (r.foto_url ?? "").trim();
        if (!obs && !foto) {
          return res.status(400).json({
            message: "Si una pregunta es 'No cumple', debes enviar observación o foto."
          });
        }
      }
    }

    const cumple_general = data.respuestas.every(r => r.cumple === true);

    await client.query("BEGIN");

    // Crear cabecera preoperacional
    const preRes = await client.query(
      `INSERT INTO preoperacionales (maquinaria_id, usuario_id, cumple_general, observacion_general, ubicacion, ciudad)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING id, fecha, cumple_general`,
      [data.maquinaria_id, req.user.id, cumple_general, data.observacion_general ?? null]
    );

    const preId = preRes.rows[0].id;

    // Insertar respuestas
    for (const r of data.respuestas) {
      await client.query(
        `INSERT INTO preoperacional_respuestas (preoperacional_id, pregunta_id, cumple, observacion, foto_url)
         VALUES ($1, $2, $3, $4, $5)`,

        [
          data.maquinaria_id,
          req.user.id,
          cumple_general,
          data.observacion_general ?? null,
          data.ubicacion,
          data.ciudad ?? null
        ]

      );
    }

    // “Debilitar” equipo si no cumple: lo desactivamos
    if (!cumple_general) {
      await client.query(
        `UPDATE maquinaria SET estado='desactivado' WHERE id=$1`,
        [data.maquinaria_id]
      );
    }

    await client.query("COMMIT");

    res.status(201).json({
      preoperacional: preRes.rows[0],
      debilitada: !cumple_general
    });
  } catch (err) {
    await client.query("ROLLBACK");
    if (err?.name === "ZodError") {
      return res.status(400).json({ message: "Datos inválidos", issues: err.issues });
    }
    console.error(err);
    res.status(500).json({ message: "Error guardando preoperacional" });
  } finally {
    client.release();
  }
});

export default router;