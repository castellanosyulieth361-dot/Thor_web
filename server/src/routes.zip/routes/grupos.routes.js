import { Router } from "express";
import { pool } from "../db.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";

const router = Router();


// Crear grupo
router.post("/", requireAuth, requireAdmin, async (req, res) => {
  try {

    const { nombre } = req.body;

    const result = await pool.query(
      "INSERT INTO grupos_maquinaria (nombre) VALUES ($1) RETURNING *",
      [nombre]
    );

    res.json(result.rows[0]);

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creando grupo" });
  }
});


// Listar grupos
router.get("/", requireAuth, requireAdmin, async (req, res) => {

  const result = await pool.query(
    "SELECT * FROM grupos_maquinaria ORDER BY id"
  );

  res.json(result.rows);

});

export default router;