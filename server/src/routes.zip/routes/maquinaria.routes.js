import { Router } from "express";
import { z } from "zod";
import { pool } from "../db.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import QRCode from "qrcode";

const router = Router();

const crearMaquinariaSchema = z.object({
  nombre: z.string().min(2),
  serial: z.string().min(2),
  marca: z.string().min(2),
  modelo: z.string().optional(),
  foto_url: z.string().optional(),
  grupo_id: z.number().int().positive()
});

// Crear maquinaria + QR fijo
router.post("/", requireAuth, requireAdmin, async (req, res) => {
  try {
    const data = crearMaquinariaSchema.parse(req.body);

    // formulario del grupo
    const formRes = await pool.query(
      "SELECT id FROM formularios WHERE grupo_id=$1",
      [data.grupo_id]
    );
    const formularioId = formRes.rows[0]?.id;
    if (!formularioId) {
      return res.status(400).json({ message: "Ese grupo no tiene formulario asignado todavía" });
    }

    // crear maquinaria
    const insert = await pool.query(
      `INSERT INTO maquinaria (nombre, serial, marca, modelo, foto_url, grupo_id, formulario_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING *`,
      [
        data.nombre.trim(),
        data.serial.trim(),
        data.marca.trim(),
        data.modelo ?? null,
        data.foto_url ?? null,
        data.grupo_id,
        formularioId
      ]
    );

    const maq = insert.rows[0];

    // QR URL (ruta del front)
    const qrUrl = `${process.env.BASE_URL}/preoperacional/${maq.qr_token}`;
    const qrDataUrl = await QRCode.toDataURL(qrUrl);

    res.status(201).json({
      maquinaria: maq,
      qr: { url: qrUrl, dataUrl: qrDataUrl }
    });
  } catch (err) {
    if (err?.name === "ZodError") return res.status(400).json({ message: "Datos inválidos", issues: err.issues });
    console.error(err);
    // serial único
    if (String(err).includes("maquinaria_serial_key")) {
      return res.status(409).json({ message: "Ya existe una máquina con ese serial" });
    }
    res.status(500).json({ message: "Error creando maquinaria" });
  }
});

// Listar maquinaria (para cards del admin)
router.get("/", requireAuth, requireAdmin, async (req, res) => {
  const { grupo_id } = req.query;

  const params = [];
  let where = "";
  if (grupo_id) {
    params.push(Number(grupo_id));
    where = "WHERE m.grupo_id = $1";
  }

  const r = await pool.query(
    `SELECT m.id, m.nombre, m.serial, m.marca, m.modelo, m.foto_url, m.estado, m.dado_baja, m.qr_token,
            g.nombre AS grupo
     FROM maquinaria m
     JOIN grupos_maquinaria g ON g.id = m.grupo_id
     ${where}
     ORDER BY m.creado_en DESC`,
    params
  );

  res.json(r.rows);
});

// Detalle maquinaria (info + qr token fijo)
router.get("/:id", requireAuth, requireAdmin, async (req, res) => {
  const { id } = req.params;

  const r = await pool.query(
    `SELECT m.*, g.nombre AS grupo
     FROM maquinaria m
     JOIN grupos_maquinaria g ON g.id = m.grupo_id
     WHERE m.id = $1`,
    [id]
  );

  const maq = r.rows[0];
  if (!maq) return res.status(404).json({ message: "Maquinaria no existe" });

  const qrUrl = `${process.env.BASE_URL}/preoperacional/${maq.qr_token}`;
  const qrDataUrl = await QRCode.toDataURL(qrUrl);

  res.json({ maquinaria: maq, qr: { url: qrUrl, dataUrl: qrDataUrl } });
});

// Cambiar estado activo/desactivado (admin)
router.patch("/:id/estado", requireAuth, requireAdmin, async (req, res) => {
  const { id } = req.params;
  const { estado } = req.body; // 'activo' | 'desactivado'

  if (!["activo", "desactivado"].includes(estado)) {
    return res.status(400).json({ message: "Estado inválido" });
  }

  const r = await pool.query(
    `UPDATE maquinaria SET estado=$1 WHERE id=$2 RETURNING *`,
    [estado, id]
  );
  if (r.rowCount === 0) return res.status(404).json({ message: "Maquinaria no existe" });

  res.json(r.rows[0]);
});

// Dar de baja (admin)
router.patch("/:id/baja", requireAuth, requireAdmin, async (req, res) => {
  const { id } = req.params;
  const { dado_baja } = req.body; // true/false

  const r = await pool.query(
    `UPDATE maquinaria SET dado_baja=$1 WHERE id=$2 RETURNING *`,
    [Boolean(dado_baja), id]
  );
  if (r.rowCount === 0) return res.status(404).json({ message: "Maquinaria no existe" });

  res.json(r.rows[0]);
});

// Buscar maquinaria por nombre o serial (para colaborador)
router.get("/search", requireAuth, async (req, res) => {
  const { q } = req.query;

  if (!q) return res.json([]);

  const r = await pool.query(
    `SELECT id, nombre, serial, foto_url, estado
     FROM maquinaria
     WHERE nombre ILIKE $1 OR serial ILIKE $1
     ORDER BY nombre ASC
     LIMIT 20`,
    [`%${q}%`]
  );

  res.json(r.rows);
});

// Obtener formulario según la maquinaria
router.get("/:id/formulario", requireAuth, async (req, res) => {
  const { id } = req.params;

  const maqRes = await pool.query(
    `SELECT id, nombre, serial, formulario_id
     FROM maquinaria
     WHERE id=$1`,
    [id]
  );

  const maq = maqRes.rows[0];
  if (!maq) return res.status(404).json({ message: "Maquinaria no existe" });

  const preguntasRes = await pool.query(
    `SELECT id, enunciado, orden
     FROM formulario_preguntas
     WHERE formulario_id=$1 AND activa=true
     ORDER BY orden ASC`,
    [maq.formulario_id]
  );

  res.json({
    maquinaria: maq,
    preguntas: preguntasRes.rows
  });
});
export default router;